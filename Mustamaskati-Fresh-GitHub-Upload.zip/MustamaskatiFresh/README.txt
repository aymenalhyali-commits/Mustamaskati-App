Mustamaskati GitHub build starter

Upload BOTH items to the ROOT of a new GitHub repository:
1) MustamaskatiAndroid-GitHub.zip
2) .github/workflows/build-apk.yml (keep this exact folder path)

The workflow extracts the Android project ZIP and builds a debug APK using GitHub Actions.
Then open Actions > Build Mustamaskati APK > latest successful run > Artifacts.
