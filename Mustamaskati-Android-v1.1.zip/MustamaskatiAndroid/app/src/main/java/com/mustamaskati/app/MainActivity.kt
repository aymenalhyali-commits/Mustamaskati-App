package com.mustamaskati.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val scanRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = 0
        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    view: WebView?,
                    callback: ValueCallback<Array<Uri>>?,
                    params: FileChooserParams?
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    launchDocumentScanner()
                    return true
                }
            }
            addJavascriptInterface(PrintBridge(this@MainActivity), "AndroidPrint")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun launchDocumentScanner() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(1)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { sender ->
                try {
                    startIntentSenderForResult(sender, scanRequest, null, 0, 0, 0)
                } catch (_: Exception) {
                    openGalleryFallback()
                }
            }
            .addOnFailureListener { openGalleryFallback() }
    }

    private fun openGalleryFallback() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(intent, "اختيار صورة المستمسك"), scanRequest)
    }

    @Deprecated("Deprecated by Android; retained for compatibility with scanner intent")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != scanRequest) return
        var selected: Uri? = null
        if (resultCode == RESULT_OK && data != null) {
            val scan = GmsDocumentScanningResult.fromActivityResultIntent(data)
            selected = scan?.pages?.firstOrNull()?.imageUri ?: data.data
        }
        fileCallback?.onReceiveValue(selected?.let { arrayOf(it) })
        fileCallback = null
    }

    class PrintBridge(private val activity: Activity) {
        @JavascriptInterface
        fun printPages() {
            activity.runOnUiThread {
                val main = activity as MainActivity
                val manager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = main.webView.createPrintDocumentAdapter("مستمسكاتي")
                manager.print("مستمسكاتي", adapter, PrintAttributes.Builder().build())
            }
        }
    }

    @Deprecated("Deprecated by Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
