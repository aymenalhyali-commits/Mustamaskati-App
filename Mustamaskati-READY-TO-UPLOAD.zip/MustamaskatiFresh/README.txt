Mustamaskati Android project archive.
Upload this ZIP to the GitHub repository root. The repository workflow extracts this outer archive and then extracts MustamaskatiAndroid-GitHub.zip to build the APK.
The Android project targets Java 17 and Kotlin JVM 17.
